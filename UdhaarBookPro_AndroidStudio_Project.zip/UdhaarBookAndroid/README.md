# UdhaarBook Pro Android Project

Open this folder in Android Studio.
Then: Build > Build APK(s).

Package: com.udhaarbook.pro
App: UdhaarBook Pro
